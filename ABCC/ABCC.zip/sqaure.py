for i in range(10):
    print(i * i)

def x( a , b ):
    x = 0
    y = "hello world"
    return x